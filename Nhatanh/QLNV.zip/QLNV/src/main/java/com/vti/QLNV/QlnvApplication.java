package com.vti.QLNV;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QlnvApplication {

	public static void main(String[] args) {
		SpringApplication.run(QlnvApplication.class, args);
	}

}
