package com.vti.QLNV;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QlnvApplicationTests {

	@Test
	void contextLoads() {
	}

}
