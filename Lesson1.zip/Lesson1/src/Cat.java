public class Cat {
    String mauLong;
    String loai;
    int soTai;
    int soTuoi;
    Gender gender;

    public void keu(){
        System.out.println(loai+ " meo meo .....");
    }
}
