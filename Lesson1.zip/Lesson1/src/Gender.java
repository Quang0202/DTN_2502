public enum Gender {
    MALE, FEMALE, UNKNOWN
}
