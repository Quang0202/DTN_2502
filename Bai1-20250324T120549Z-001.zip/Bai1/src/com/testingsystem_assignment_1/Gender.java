package com.testingsystem_assignment_1;

public enum Gender {
    MALE, FEMALE, UNKNOWN
}
