import Entity.*;

public class Program {

	public static void main(String[] args) {
        HinhChuNhat hcn = new HinhChuNhat(10,5);
        hcn.tinhChuVi();
        
        HinhVuong hv = new HinhVuong(10);
        hv.tinhChuVi();
        
        MyMath myMath = new MyMath();

        int intSum = myMath.sum(10, 20);
        float floatSum = myMath.sum(1.5f, 2.5f);
        byte byteSum = myMath.sum((byte)5, (byte)10);

        System.out.println("Tổng int: " + intSum);
        System.out.println("Tổng float: " + floatSum);
        System.out.println("Tổng byte: " + byteSum);
        
        
        System.out.println("=== Điện thoại cổ điển ===");
        DienThoaiCoDien nokia = new DienThoaiCoDien();
        nokia.goiDien();
        nokia.ngheRadio();
        nokia.tanCong();

        System.out.println("\n=== Điện thoại thông minh ===");
        DienThoaiThongMinh iphone = new DienThoaiThongMinh();
        iphone.guiTinNhan();
        iphone.suDung3G();
        iphone.chupHinh();
        iphone.tanCong();
	}

}
