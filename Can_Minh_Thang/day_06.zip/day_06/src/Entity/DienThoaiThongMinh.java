package Entity;

import Interface.DienThoai;

public class DienThoaiThongMinh extends DienThoai {
    public void suDung3G() {
        System.out.println("Sử dụng 3G để lướt web, xem video...");
    }

    public void chupHinh() {
        System.out.println("Chụp hình bằng camera điện thoại thông minh...");
    }
}
