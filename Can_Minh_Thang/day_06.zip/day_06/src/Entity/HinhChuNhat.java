package Entity;

public class HinhChuNhat {
	private float chieuDai;
	private float chieuRong;

	public HinhChuNhat(float chieuDai, float chieuRong) {
		this.chieuDai = chieuDai;
		this.chieuRong = chieuRong;
	}

	public void tinhChuVi() {
		float chuVi = (chieuDai + chieuRong) * 2;
		if (this instanceof HinhVuong) {
			System.out.println("Chu vi hinh vuong: " + chuVi);
		} else {
			System.out.println("Chu vi hinh chu nhat: " + chuVi);
		}
	}

	public void tinhDienTich() {
		System.out.println("Dien tich la : " + (chieuDai * chieuRong));
	}
}