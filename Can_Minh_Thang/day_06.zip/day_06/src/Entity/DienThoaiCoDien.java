package Entity;

import Interface.DienThoai;

public class DienThoaiCoDien extends DienThoai {
    public void ngheRadio() {
        System.out.println("Nghe đài radio trên điện thoại cổ điển...");
    }
}
