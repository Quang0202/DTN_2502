package Entity;

public class HinhVuong extends HinhChuNhat {
	public HinhVuong(float canh) {
		super(canh, canh);
	}
}