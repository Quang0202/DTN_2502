package Interface;

public interface ChucNangCoBan {
    void goiDien();
    void ngheDien();
    void guiTinNhan();
    void nhanTinNhan();
}
