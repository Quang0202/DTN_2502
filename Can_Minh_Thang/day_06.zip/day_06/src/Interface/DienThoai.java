package Interface;

public abstract class DienThoai implements ChucNangCoBan, VuKhi {
	@Override
	public void goiDien() {
        System.out.println("Gọi điện thoại...");
    }

    @Override
    public void ngheDien() {
        System.out.println("Nghe điện thoại...");
    }

    @Override
    public void guiTinNhan() {
        System.out.println("Gửi tin nhắn...");
    }

    @Override
    public void nhanTinNhan() {
        System.out.println("Nhận tin nhắn...");
    }

    @Override
    public void tanCong() {
        System.out.println("Dùng điện thoại để tấn công kẻ xấu!");
    }

}
