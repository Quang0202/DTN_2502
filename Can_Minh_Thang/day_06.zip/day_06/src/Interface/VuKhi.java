package Interface;

public interface VuKhi {
    void tanCong();
}
