
public class CategoryQuestion {
	int categoryId;
	String categoryQuestion;
	
	public CategoryQuestion(int categoryId, String categoryQuestion) {
		super();
		this.categoryId = categoryId;
		this.categoryQuestion = categoryQuestion;
	}
	
	@Override
	public String toString() {
		return "CategoryQuestion [categoryId=" + categoryId + ", categoryQuestion=" + categoryQuestion + "]";
	}
	
}
