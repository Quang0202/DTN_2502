import java.time.LocalDateTime;

public class GroupAccount {
	int groupId;
	Account account;
	LocalDateTime joinDate;
	
	public GroupAccount(int groupId, Account account, LocalDateTime joinDate) {
		super();
		this.groupId = groupId;
		this.account = account;
		this.joinDate = joinDate;
	}
	
	@Override
	public String toString() {
		return "GroupAccount [groupId=" + groupId + ", account=" + account + ", joinDate=" + joinDate + "]";
	}
	
}
