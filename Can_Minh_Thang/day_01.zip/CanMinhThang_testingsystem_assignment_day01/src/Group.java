import java.time.LocalDateTime;

public class Group {
	int groupId;
	String groupName;
	Account[] account;
	LocalDateTime createDate;
	
	public Group(int groupId, String groupName, Account[] account) {
		super();
		this.groupId = groupId;
		this.groupName = groupName;
		this.account = account;
		this.createDate = Utility.currentTime();
	}

	@Override
	public String toString() {
		return "Group [groupId=" + groupId + ", groupName=" + groupName + ", account=" + account + ", createDate="
				+ createDate + "]";
	}
	
	public int getNumberOfAccounts() {
		return account.length;
	}
	
}
