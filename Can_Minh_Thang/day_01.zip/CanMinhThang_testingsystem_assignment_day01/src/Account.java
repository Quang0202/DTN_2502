import java.time.LocalDateTime;

public class Account {
	int accountId;
	String email;
	String userName;
	String fullName;
	Department department;
	Position position;
	LocalDateTime createDate;
	String[] groups;
	
	public Account(int accountId, String email, String userName, String fullName, Department department,
			Position position) {
		super();
		this.accountId = accountId;
		this.email = email;
		this.userName = userName;
		this.fullName = fullName;
		this.department = department;
		this.position = position;
		this.createDate = Utility.currentTime();
		this.groups = new String[0];
	}

	public Account(int accountId, String email, String userName, String fullName, Position position) {
		super();
		this.accountId = accountId;
		this.email = email;
		this.userName = userName;
		this.fullName = fullName;
		this.position = position;
		this.createDate = Utility.currentTime();
		this.groups = new String[0];
	}

	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", email=" + email + ", userName=" + userName + ", fullName="
				+ fullName + ", department=" + department + ", position=" + position + ", createDate=" + createDate
				+ "]";
	}

	public Department getDepartment() {
		return department;
	}
	
	public String getDepartmentName() {
		if (department != null && department.departmentName != null) {
			return department.departmentName;
		}
		return "Chưa có phòng ban";
	}
	
	public void setGroup(String[] groups) {
		this.groups = groups;
	}
	
	public String[] getGroup() {
		return groups;
	}
	
	public Position getPosition() {
		return position;
	}
	
	public String getPositionName() {
		if (position != null && position.positionName != null) {
			return position.positionName;
		}
		return position.positionName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	
}
