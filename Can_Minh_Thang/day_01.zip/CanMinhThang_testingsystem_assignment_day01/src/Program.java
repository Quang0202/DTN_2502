
public class Program {
	public static void main(String[] args) {

		Department department1 = new Department(1, "Sale");
		Department department2 = new Department(2, "Marketing");
		Department department3 = new Department(3, "HR");

		Position position1 = new Position(1, "HR");
		Position position2 = new Position(2, "Dev");

		Account acc1 = new Account(1, "nguyenvana@gmail.com", "nguyenvana", "Nguyễn Văn A", department1, position1);
		Account acc2 = new Account(2, "tranthib@gmail.com", "tranthib", "Trần Thị B", position1);
		acc2.setGroup(new String[] { "Java Fresher", "C# Fresher", "Developer" });

		System.out.println(acc1);
		System.out.println(acc2);

		// Question 1:
		if (acc1.getDepartment() == null) {
			System.out.println("Nhân viên này chưa có phòng ban");
		} else {
			System.out.println("Phòng ban của nhân viên này là : " + acc1.getDepartmentName());
		}

		// Question 2: Kiểm tra account thứ 2 có group không
		if (acc2.getGroup() == null || acc2.getGroup().length == 0) {
			System.out.println("Nhân viên này chưa có group");
		} else if (acc2.getGroup().length == 1 || acc2.getGroup().length == 2) {
			System.out.println("Group của nhân viên này là " + String.join(", ", acc2.getGroup()));
		} else if (acc2.getGroup().length == 3) {
			System.out.println("Nhân viên này là người quan trọng, tham gia nhiều group");
		} else {
			System.out.println("Nhân viên này là người hóng chuyện, tham gia tất cả các group");
		}

		// Question 3: Dùng toán tử ternary để kiểm tra phòng ban của acc2
		System.out.println(acc2.getDepartment() == null ? "Nhân viên này chưa có phòng ban"
				: "Phòng ban của nhân viên này là: " + acc2.getDepartmentName());

		// Question 4: Dùng toán tử ternary để kiểm tra position của acc1
		System.out.println(acc1.getPosition() == null ? "Nhân viên này chưa có vị trí"
				: "Vị trí của nhân viên này là: " + acc1.getPositionName());

		// Question 5: Dùng switch case để kiểm tra số lượng account trong nhóm thứ 1
		Group group1 = new Group(1, "Java Fresher", new Account[] { acc1, acc2 });

		switch (group1.getNumberOfAccounts()) {
		case 1:
			System.out.println("Nhóm có 1 thành viên");
			break;
		case 2:
			System.out.println("Nhóm có 2 thành viên");
		case 3:
			System.out.println("Nhóm có 3 thành viên");
		default:
			System.out.println("Nhóm có nhiều thành viên");
		}

		// Question 6: Sử dụng switch case để làm lại Question 2
		int groupCount = acc2.getGroup() == null ? 0 : acc2.getGroup().length;
		switch (groupCount) {
		case 0:
			System.out.println("Nhân viên này chưa có group");
			break;
		case 1:
		case 2:
			System.out.println("Group của nhân viên này là " + String.join(", ", acc2.getGroup()));
			break;
		case 3:
			System.out.println("Nhân viên này là người quan trọng, tham gia nhiều group");
			break;
		case 4:
			System.out.println("Nhân viên này là người hóng chuyện, tham gia tất cả các group");
			break;
		}

		// Question 7: Sử dụng switch case để làm lại Question 4:
		Position devPosition = new Position(3, "DEV");

		Account acc3 = new Account(1, "nguyenvanc@gmail.com", "nguyenvanc", "Nguyễn Văn C", department1, devPosition);

		switch (acc3.getPositionName()) {
		case "DEV":
			System.out.println("Đây là Developer");
			break;
		default:
			System.out.println("Người này không phải Developer");
			break;
		}

		// Question 8: Duyệt mảng các tài khoản và in ra thông tin
		Account[] accounts = { acc1, acc2, acc3 };
		for (Account account : accounts) {
			System.out.println("Email: " + account.getEmail());
			System.out.println("Full Name: " + account.getFullName());
			System.out.println("Department: "
					+ (account.getDepartment() != null ? account.getDepartmentName() : "Không có phòng ban!"));
			System.out.println("-----------------");
		}

		// Question 9: Duyệt danh sách phòng ban và in ra ID, Name
		Department[] departments = { department1, department2, department3 };

		for (Department department : departments) {
			System.out.println("Id: " + department.getDepartmentId());
			System.out.println("Name: " + department.getDepartmentName());
			System.out.println("----------------");
		}

		// Question 10: In thông tin account theo định dạng
		for (int i = 0; i < accounts.length; i++) {
			System.out.println("Thông tin account thứ " + (i + 1) + " là:");
			System.out.println("Email: " + accounts[i].getEmail());
			System.out.println("Full name: " + accounts[i].getFullName());
			System.out.println("Phòng ban: "
					+ (accounts[i].getDepartment() != null ? accounts[i].getDepartment().getDepartmentName()
							: "Chưa có phòng ban"));
			System.out.println("-------------------");
		}

		// Question 11: In ra thông tin phòng ban theo định dạng yêu cầu
		for (int i = 0; i < departments.length; i++) {
			System.out.println("Thông tin department thứ " + (i + 1) + " là:");
			System.out.println("Id: " + departments[i].getDepartmentId());
			System.out.println("Name: " + departments[i].getDepartmentName());
			System.out.println("-------------------");
		}

		// Question 12: In ra 2 phòng ban như định dạng Question 11
		int count = Math.min(2, departments.length);
		for (int i = 0; i < count; i++) {
			System.out.println("Thông tin department thứ " + (i + 1) + " là:");
			System.out.println("Id: " + departments[i].getDepartmentId());
			System.out.println("Name: " + departments[i].getDepartmentName());
			System.out.println("-------------------");
		}

		// Question 13: In tất cả account ngoại trừ account thứ 2
		for (int i = 0; i < accounts.length; i++) {
			if (i == 1) {
				continue;
			}
			System.out.println("Thông tin account thứ " + (i + 1) + ":");
			System.out.println("Email: " + accounts[i].getEmail());
			System.out.println("Full name: " + accounts[i].getFullName());
			System.out.println("Phòng ban: " + accounts[i].getDepartment().getDepartmentName());
			System.out.println("----------------------");
		}

		// Question 14: In ra tất cả account có id < 4
		for (Account account : accounts) {
			if (account.getAccountId() < 4) {
				System.out.println("Thông tin account có ID < 4:");
				System.out.println("ID: " + account.getAccountId());
				System.out.println("Email: " + account.getEmail());
				System.out.println("Full name: " + account.getFullName());
				System.out.println("Phòng ban: " + account.getDepartmentName());
				System.out.println("----------------------");
			}
		}

		// Question 15: In ra số chẵn nhỏ hơn hoặc bằng 20
		System.out.println("Số chẵn nhỏ hơn hoặc bằng 20:");
		for (int i = 2; i <= 20; i += 2) {
			System.out.print(i + " ");
		}

		// Question 16: Làm lại bài 15 bằng while
		System.out.println("");
		System.out.println("Số chẵn nhỏ hơn hoặc bằng 20 (While):");
		int q16 = 2;
		while (q16 <= 20) {
			System.out.print(q16 + " ");
			q16 += 2;
		}
		
		// Question 17: Làm lại bài 15 bằng do-while
		System.out.println("");		
		System.out.println("Số chẵn nhỏ hơn hoặc bằng 20 (Do - While)");
		int q17 = 2;
		do {
			System.out.print(q17 + " ");
			q17 += 2 ;
		} while (q17 <= 20);
		
		// Question 18: Khai báo số nguyên 5 và in ra
		System.out.println("");
		int q18 = 5;
		System.out.println(q18);
		
		// Question 19: Khai báo số nguyên = 1000000 và dùng printf để in ra định dạng 100,000,000
		int q19 = 100_000_000;
		System.out.printf("%,d%n", q19);
		
		// Question 20: Khai báo 1 số thực 5,567098 và in ra 4 số đằng sau dấu phẩy
		double q20 = 5.567098;
		System.out.printf("%.4f%n", q20);
		
	}
}
