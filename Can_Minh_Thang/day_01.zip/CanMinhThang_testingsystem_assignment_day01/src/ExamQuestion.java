
public class ExamQuestion {
	Exam exam;
	Question question;
	
	public ExamQuestion(Exam exam, Question question) {
		super();
		this.exam = exam;
		this.question = question;
	}
	
	@Override
	public String toString() {
		return "ExamQuestion [exam=" + exam + ", question=" + question + "]";
	}
	
}
