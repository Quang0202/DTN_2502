import java.time.LocalDateTime;

public class Exam {
	int examId;
	String code;
	String title;
	CategoryQuestion categoryQuestion;
	int duration;
	Account account;
	LocalDateTime createDate;
	
	public Exam(int examId, String code, String title, CategoryQuestion categoryQuestion, int duration, Account account,
			LocalDateTime createDate) {
		super();
		this.examId = examId;
		this.code = code;
		this.title = title;
		this.categoryQuestion = categoryQuestion;
		this.duration = duration;
		this.account = account;
		this.createDate = createDate;
	}
	
	@Override
	public String toString() {
		return "Exam [examId=" + examId + ", code=" + code + ", title=" + title + ", categoryQuestion="
				+ categoryQuestion + ", duration=" + duration + ", account=" + account + ", createDate=" + createDate
				+ "]";
	}
	
}
