import java.time.LocalDateTime;

public class Question {
	int questionId;
	String content;
	CategoryQuestion categoryQuestion;
	TypeQuestion typeQuestion;
	Account account;
	LocalDateTime createDate;
	
	public Question(int questionId, String content, CategoryQuestion categoryQuestion, TypeQuestion typeQuestion,
			Account account, LocalDateTime createDate) {
		super();
		this.questionId = questionId;
		this.content = content;
		this.categoryQuestion = categoryQuestion;
		this.typeQuestion = typeQuestion;
		this.account = account;
		this.createDate = createDate;
	}
	
	@Override
	public String toString() {
		return "Question [questionId=" + questionId + ", content=" + content + ", categoryQuestion=" + categoryQuestion
				+ ", typeQuestion=" + typeQuestion + ", account=" + account + ", createDate=" + createDate + "]";
	}
	
}
