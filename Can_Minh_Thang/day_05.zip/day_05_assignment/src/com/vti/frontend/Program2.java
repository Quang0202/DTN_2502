package com.vti.frontend;

import com.vti.backend.Excercise2;

public class Program2 {
    public static void main(String[] args) {
    	Excercise2 ex2 = new Excercise2();
        ex2.excercise2();
    }
}
