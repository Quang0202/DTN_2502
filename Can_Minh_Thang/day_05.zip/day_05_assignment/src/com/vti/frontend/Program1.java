package com.vti.frontend;

import com.vti.backend.*;

public class Program1 {
    public static void main(String[] args) {
    	Excercise1 ex1 = new Excercise1();
        ex1.excercise1();
    }
}
