package com.vti.frontend;

import com.vti.entity.*;

public class Program4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student2 = new Student("nguyenvana", "hanoi");
		
		System.out.println(student2);
		
		student2.setScore(4);
		
		System.out.println(student2);
		
		student2.addPoint(8);
		
		System.out.println(student2);
		
		student2.addPoint(5);
		
		System.out.println(student2);
	}

}
