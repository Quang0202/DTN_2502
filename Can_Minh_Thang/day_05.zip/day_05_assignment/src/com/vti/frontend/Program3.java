package com.vti.frontend;

import com.vti.backend.Excercise3;

public class Program3 {
    public static void main(String[] args) {
    	Excercise3 ex3 = new Excercise3();
    	ex3.excersise3();
    }
}
