package com.vti.frontend;

public class Program {

	public static void main(String[] args) {
		Program1.main(args);
		Program2.main(args);
		Program3.main(args);
		Program4.main(args);
	}

}
