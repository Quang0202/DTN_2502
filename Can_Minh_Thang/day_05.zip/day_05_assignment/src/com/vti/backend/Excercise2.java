package com.vti.backend;

import java.util.List;
import java.util.ArrayList;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.vti.entity.*;

public class Excercise2 {
	
	public void excercise2() {
		
		Position position1 = new Position(1, "DEV");
		Position position2 = new Position(2, "MANAGER");
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		LocalDateTime createDate = LocalDateTime.parse("2025-02-02 00:00:00", formatter);
		
		Account account1 = new Account();
		Account account2 = new Account(1, "cmthang2407@gmail.com", "ThangCM", "Can", "Thang");
		Account account3 = new Account(2, "cmthang2407@gmail.com", "ThangCM", "Can", "Thang",position1);
		Account account4 = new Account(3, "cmthang2407@gmail.com", "ThangCM", "Can", "Thang", position2, createDate);
		
		List<Account> accounts = new ArrayList<>();
		accounts.add(account1);
		accounts.add(account2);
		accounts.add(account3);
		accounts.add(account4);
		
		for (Account account : accounts) {
			System.out.println(account);
		}
		
	}
	
}
