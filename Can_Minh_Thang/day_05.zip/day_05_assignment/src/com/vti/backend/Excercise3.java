package com.vti.backend;

import java.util.List;
import java.util.ArrayList;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.vti.entity.*;

public class Excercise3 {
	
	public void excersise3 () {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		LocalDateTime createDate = LocalDateTime.parse("2025-02-02 00:00:00", formatter);
		Account account1 = new Account();
		Account account2 = new Account(1, "cmthang2407@gmail.com", "ThangCM", "Can", "Thang");

		Group group1 = new Group();
		Group group2 = new Group("Group2", account2, List.of(account2), createDate);
		Group group3 = new Group("Group3", account2, new String[]{"nguyenvana", "nguyenvanb"}, createDate);
		
		List<Group> groups = new ArrayList<>();
		groups.add(group1);
		groups.add(group2);
		groups.add(group3);
		
		for (Group group : groups) {
			System.out.println(group);
		}
		
	}
}
