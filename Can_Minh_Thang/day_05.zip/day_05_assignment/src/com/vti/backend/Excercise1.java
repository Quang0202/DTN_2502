package com.vti.backend;

import java.util.ArrayList;
import java.util.List;

import com.vti.entity.*;

public class Excercise1 {
	
	public void excercise1() {
		
		Department department1 = new Department();
		Department department2 = new Department("HR");

		List<Department> departments = new ArrayList<>();
		departments.add(department1);
		departments.add(department2);

		for (Department department : departments) {
			System.out.println(department);
		}

	}
}
