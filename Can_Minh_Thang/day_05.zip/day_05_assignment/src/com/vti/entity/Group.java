package com.vti.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Group {
	private String groupName;
	private Account account;
	private List<Account> accounts;
	private LocalDateTime createDate;
	
	public Group() {
		super();
	}

	public Group(String groupName, Account account, List<Account> accounts, LocalDateTime createDate) {
		super();
		this.groupName = groupName;
		this.account = account;
		this.accounts = accounts;
		this.createDate = createDate;
	}

	public Group(String groupName, Account account, String[] userNames, LocalDateTime createDate) {
		super();
		this.groupName = groupName;
		this.account = account;
		this.createDate = createDate;
		
		this.accounts = new ArrayList<>();
		
		for (String userName : userNames) {
			Account newAccount = new Account();
			newAccount.setUserName(userName);
			this.accounts.add(newAccount);
		}
	}

	@Override
	public String toString() {
		return "Group [groupName=" + groupName + ", account=" + account + ", accounts=" + accounts + ", createDate="
				+ createDate + "]";
	}
	
	
}
