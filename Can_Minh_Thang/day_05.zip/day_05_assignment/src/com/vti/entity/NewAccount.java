package com.vti.entity;

public class NewAccount {
	private int id;
	private String name;
	private int balance;
	
	public NewAccount(int id, String name, int balance) {
		super();
		this.id = id;
		this.name = name;
		this.balance = balance;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public int getBalance() {
		return balance;
	}

	public void credit(int amount) {
		this.balance += amount;
	}
	
	public void debit(int amount) {
		if (balance >= amount) {
			balance -= amount;
		} else {
			System.out.println("Số dư không đủ để rút tiền!");
		}
	}
	
	public String transferTo(NewAccount account, int amount) {
		if (balance >= amount && account !=null) {
			balance -= amount;
			account.credit(amount);
			return "Chuyển tiền thành công!";
		} else {
			return "Tài khoản không tồn tại hoặc số dư không đủ! Vui lòng kiểm tra lại!";
		}
	}
	
}
