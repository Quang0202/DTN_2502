package com.vti.entity;

public class Department {
	private int departmentId;
	private String departmentName;
	
	public Department(String departmentName) {
		super();
		this.departmentId = 0;
		this.departmentName = departmentName;
	}

	public Department() {
		super();
	}

	@Override
	public String toString() {
		return "Department [departmentId=" + departmentId + ", departmentName=" + departmentName + "]";
	}
	
	
}
