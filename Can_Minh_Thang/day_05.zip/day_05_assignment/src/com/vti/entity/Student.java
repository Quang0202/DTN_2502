package com.vti.entity;

public class Student {
	private int Id;
	private String name;
	private String hometown;
	private float score;

	public Student(String name, String hometown) {
		super();
		this.name = name;
		this.hometown = hometown;
		this.score = 0;
	}

	public float getScore() {
		return score;
	}

	public void setScore(float score) {
		this.score = score;
	}

	public void addPoint(float score) {
		float newScore = this.score + score;
		if (newScore > 10 || newScore < 0) {
			System.out.println("Điểm không hợp lệ! Thao tác thất bại!");
		} else {
			this.score += score;
		}
	}

	public String getStudentGrade() {
		if (score < 4)
			return "Yếu";
		else if (score < 6)
			return "Trung bình";
		else if (score < 8)
			return "Khá";
		else
			return "Giỏi";
	}

	@Override
	public String toString() {
		return "Student [Id=" + Id + ", name=" + name + ", hometown=" + hometown + ", score=" + score + ", grade="+ getStudentGrade() +"]";
	}

}
