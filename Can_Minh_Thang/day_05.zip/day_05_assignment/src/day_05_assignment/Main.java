package day_05_assignment;

import java.util.List;
import java.util.ArrayList;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.vti.frontend.Program;

public class Main {

	public static void main(String[] args) {
		
//		// Question 1		
//		Department department1 = new Department();
//		Department department2= new Department("HR");
//		
//		List<Department> departments = new ArrayList<>();
//		departments.add(department1);
//		departments.add(department2);
//		
//		for (Department department : departments) {
//			System.out.println(department);
//		}
//		
//		// Question 2
//		Position position1 = new Position(1, "DEV");
//		Position position2 = new Position(2, "MANAGER");
//		
//		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
//		LocalDateTime createDate = LocalDateTime.parse("2025-02-02 00:00:00", formatter);
//		
//		Account account1 = new Account();
//		Account account2 = new Account(1, "cmthang2407@gmail.com", "ThangCM", "Can", "Thang");
//		Account account3 = new Account(2, "cmthang2407@gmail.com", "ThangCM", "Can", "Thang",position1);
//		Account account4 = new Account(3, "cmthang2407@gmail.com", "ThangCM", "Can", "Thang", position2, createDate);
//		
//		List<Account> accounts = new ArrayList<>();
//		accounts.add(account1);
//		accounts.add(account2);
//		accounts.add(account3);
//		accounts.add(account4);
//		
//		for (Account account : accounts) {
//			System.out.println(account);
//		}
//		
//		// Question 3:
//		Group group1 = new Group();
//		Group group2 = new Group("Group2", account2, List.of(account2), createDate);
//		Group group3 = new Group("Group3", account2, new String[]{"nguyenvana", "nguyenvanb"}, createDate);
//		
//		List<Group> groups = new ArrayList<>();
//		groups.add(group1);
//		groups.add(group2);
//		groups.add(group3);
//		
//		for (Group group : groups) {
//			System.out.println(group);
//		}
		
		Program.main(args);
	}

}
