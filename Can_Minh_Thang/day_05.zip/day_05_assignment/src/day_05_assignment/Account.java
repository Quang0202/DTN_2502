package day_05_assignment;

import java.time.LocalDateTime;

public class Account {
	private int accountId;
	private String email;
	private String userName;
	private String fullName;
	private String firstName;
	private String lastName;
	private Position position;
	private LocalDateTime createDate;
	
	public Account() {
		super();
	}
	
	public Account(int accountId, String email, String userName, String firstName, String lastName) {
		super();
		this.accountId = accountId;
		this.email = email;
		this.userName = userName;
		this.fullName = firstName + lastName;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public Account(int accountId, String email, String userName, String firstName, String lastName,
			Position position) {
		super();		
		this.accountId = accountId;
		this.email = email;
		this.userName = userName;
		this.fullName = firstName + lastName;
		this.firstName = firstName;
		this.lastName = lastName;
		this.position = position;
		this.createDate = LocalDateTime.now();
	}
	
	public Account(int accountId, String email, String userName, String firstName, String lastName,
			Position position, LocalDateTime createDate) {
		super();		
		this.accountId = accountId;
		this.email = email;
		this.userName = userName;
		this.fullName = firstName + lastName;
		this.firstName = firstName;
		this.lastName = lastName;
		this.position = position;
		this.createDate = createDate;
	}
	
	

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", email=" + email + ", userName=" + userName + ", fullName="
				+ fullName + ", firstName=" + firstName + ", lastName=" + lastName + ", position=" + position
				+ ", createDate=" + createDate + "]";
	}
	
}
