import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Comparator;

public class Main {

	public static void main(String[] args) {
		// Khởi tạo
		Scanner scanner = new Scanner(System.in);

		List<String> groups = new ArrayList<>();
		groups.add("Java");
		groups.add("Java Developer");
		groups.add("Java Backend Team");
		groups.add("Frontend Engineers");
		groups.add("Python Enthusiasts");
		groups.add("Fullstack Javascipt");

		List<Department> departments = new ArrayList<>();
		departments.add(new Department(1, "Accounting", "Hà Nội"));
		departments.add(new Department(2, "Marketing", "TP.HCM"));
		departments.add(new Department(3, "IT", "Đà Nẵng"));
        departments.add(new Department(4, "Waiting room", "Hà Nội"));
        departments.add(new Department(5, "Boss of director", "Hà Nội"));
        
        
//		day03_Ex04_Question8(groups);
//		day03_Ex04_Question9(groups);
//		day03_Ex04_Question10(scanner);
//		day03_Ex04_Question11(scanner);
//		day03_Ex04_Question12(scanner);
//		day03_Ex04_Question13(scanner);
//		day03_Ex04_Question14(scanner);
//		day04_Ex04_Question15(scanner);
//		day04_Ex04_Question16(scanner);

//		day04_Ex05_Question1(departments);
//		day04_Ex05_Question2(departments);
//		day04_Ex05_Question3(departments);
//		day04_Ex05_Question4(departments);
//		day04_Ex05_Question5(departments);
		day04_Ex05_Question6(departments);
		
		scanner.close();

	}

	static void day03_Ex04_Question8(List<String> groups) {

		System.out.println("Các group chứa 'Java': ");
		for (String group : groups) {
			if (group.contains("Java")) {
				System.out.println(group);
			}
		}
	}

	static void day03_Ex04_Question9(List<String> groups) {
		System.out.println("Các group 'Java': ");
		for (String group : groups) {
			if (group.equals("Java")) {
				System.out.println(group);
			}
		}
	}

	static void day03_Ex04_Question10(Scanner scanner) {
		System.out.print("Nhập vào chuỗi 1: ");
		String str1 = scanner.nextLine().trim();
		System.out.print("Nhập vào chuỗi 2: ");
		String str2 = scanner.nextLine().trim();

		String msg = Utils.isReverse(str1, str2) ? "OK" : "KO";

		System.out.println(msg);
	}

	static void day03_Ex04_Question11(Scanner scanner) {
		System.out.println("Nhập vào chuỗi: ");
		String str = scanner.nextLine();

		int count = 0;
		char target = 'a';

		for (char c : str.toCharArray()) {
			if (c == target) {
				count++;
			}
		}

		System.out.println("Số lần xuất hiện kí tự a: " + count);
	}

	static void day03_Ex04_Question12(Scanner scanner) {
		System.out.println("Nhập vào chuỗi: ");
		String input = scanner.nextLine();

		String reverseInput = "";

		for (int i = input.length() - 1; i >= 0; i--) {
			reverseInput += input.charAt(i);
		}

		System.out.println("Chuỗi đảo ngược: " + reverseInput);
	}

	static void day03_Ex04_Question13(Scanner scanner) {
		System.out.println("Nhập vào chuỗi: ");
		String input = scanner.nextLine();

		System.out.println(Utils.isStringWithoutDigit(input));
	}

	static void day03_Ex04_Question14(Scanner scanner) {
		System.out.println("Nhập chuỗi: ");
		String input = scanner.nextLine();

		System.out.println("Nhập ký tự cần thay thế: ");
		char oldChar = scanner.next().charAt(0);

		System.out.println("Nhập ký tự thay thế: ");
		char newChar = scanner.next().charAt(0);

		System.out.println("Kết quả: " + input.replace(oldChar, newChar));

	}

	static void day04_Ex04_Question15(Scanner scanner) {
		System.out.println("Nhập chuỗi: ");
		String input = scanner.nextLine();

		input = Utils.trimSpaces(input);

		String reversed = Utils.reverseWords(input);
		System.out.println("Kết quả: " + reversed);

	}

	static void day04_Ex04_Question16(Scanner scanner) {
		System.out.println("Nhập chuỗi: ");
		String str = scanner.nextLine();

		System.out.println("Nhập số nguyên n: ");
		int n;
		while (true) {
			if (scanner.hasNextInt()) {
				n = scanner.nextInt();
				break;
			} else
				scanner.next();
		}

		if (n <= 0 || str.length() % n != 0) {
			System.out.println("KO");
		} else {
			System.out.println("Kết quả chia chuỗi:");
			for (int i = 0; i < str.length(); i += n) {
				System.out.println(str.substring(i, i + n));
			}
		}
	}

	static void day04_Ex05_Question1(List<Department> departments) {
		System.out.println("Phòng ban thứ nhất: " + departments.get(0));
	}
	
	static void day04_Ex05_Question2(List<Department> departments) {
		System.out.println("Danh sách phòng ban: ");
		for (Department department : departments) {
			System.out.println(department);			
		}
	}
	
	static void day04_Ex05_Question3(List<Department> departments) {
		System.out.println("Địa chỉ phòng ban thứ nhất: "+ departments.get(0).getAddress());
	}
	
	static void day04_Ex05_Question4(List<Department> departments) {
		if (departments.get(0).getName().equals("Phòng A")) {
			System.out.println("Phòng 1 có tên 'Phòng A'");
		} else {
			System.out.println("Phòng 1 không có tên 'Phòng A'");
		}
	}
	
	static void day04_Ex05_Question5(List<Department> departments) {
		if (departments.get(0).getName().equals(departments.get(1).getName())) {
			System.out.println("Hai phòng ban giống nhau!");
		} else {
			System.out.println("Hai phòng ban khác nhau!");
		}
	}
	
	static void day04_Ex05_Question6(List<Department> departments) {
		departments.sort(Comparator.comparing(Department::getName));
		
		for (Department department : departments) {
			System.out.println(department.getName());
		}
		
	}

}
