
public class Utils {
	static boolean isReverse(String str1, String str2) {
		return new StringBuilder(str1).reverse().toString().equals(str2);
	}

	static boolean isStringWithoutDigit(String str) {
		if (str == null)
			return false;
		for (char c : str.toCharArray()) {
			if (Character.isDigit(c))
				return false;
		}
		return true;
	}

	static String trimSpaces(String str) {
		int start = 0;
		int end = str.length() - 1;

		while (start <= end && str.charAt(start) == ' ') {
			start++;
		}

		while (end >= start && str.charAt(end) == ' ') {
			end--;
		}

		return str.substring(start, end + 1);
	}

	static String reverseWords(String str) {
		String result = "";
		String word = "";

		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);

			if (c != ' ') {
				word += c;
			} else {
				if (!word.isEmpty()) {
					result = word + (result.isEmpty() ? "" : " ") + result;
					word = "";
				}
			}
		}

		if (!word.isEmpty()) {
			result = word + (result.isEmpty() ? "" : " ") + result;
		}

		return result;
	}
}
