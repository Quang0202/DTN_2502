
import java.time.LocalDate;
import java.util.Random;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Random random = new Random();
		Scanner scanner = new Scanner(System.in);

//		Ex5_Question1(scanner);
//		Ex5_Question2(scanner);
//		Ex5_Question3(scanner);
//		Ex5_Question4(scanner);
//		Ex5_Question7(scanner);

//		Ex6_Question1();
//		Ex6_Question3();

//		Day3_Ex1_Question1();
//		int number = Day3_Ex1_Question2(random);
//		Day3_Ex1_Question3(number);
//		Day3_Ex1_Question4(scanner);

//		Day3_Ex2_Question1();
//		Day3_Ex3_Question1();
//		Day3_Ex3_Question2();
//		Day3_Ex3_Question3();

//		Day3_Ex4_Question1(scanner);
//		Day3_Ex4_Question2(scanner);
//		Day3_Ex4_Question3(scanner);
//		Day3_Ex4_Question4(scanner);
//		Day3_Ex4_Question5(scanner);
//		Day3_Ex4_Question6(scanner);
//		Day3_Ex4_Question7(scanner);
		
		scanner.close();
	}

	static void Ex5_Question1(Scanner scanner) {
		System.out.println("Nhập số nguyên");

		int num1 = Utility.getValidInput(scanner, "Số thứ nhất: ", InputType.INT);
		int num2 = Utility.getValidInput(scanner, "Số thứ hai: ", InputType.INT);
		int num3 = Utility.getValidInput(scanner, "Số thứ ba: ", InputType.INT);

		System.out.println("Các số đã nhập: " + num1 + ", " + num2 + ", " + num3);
	}

	static void Ex5_Question2(Scanner scanner) {
		System.out.println("Nhập vào số thực");

		float num1 = Utility.getValidInput(scanner, "Số thứ nhất: ", InputType.FLOAT);
		float num2 = Utility.getValidInput(scanner, "Số thứ hai: ", InputType.FLOAT);

		System.out.println("Các số đã nhập: " + num1 + ", " + num2);
	}

	static void Ex5_Question3(Scanner scanner) {
		String fullName = Utility.getValidInput(scanner, "Nhập vào họ và tên: ", InputType.FULLNAME);
		System.out.println("Họ và tên: " + Utility.capitalizeWords(fullName));

	}

	static void Ex5_Question4(Scanner scanner) {
		LocalDate dateOfBirth = Utility.getValidInput(scanner, "Nhập vào ngày sinh: ", InputType.DATETIME);
		System.out.println("Ngày sinh: " + dateOfBirth);
	}

	static void Ex5_Question7(Scanner scanner) {
		int num = Utility.getValidInput(scanner, "Nhập vào số chẵn: ", InputType.EVEN);
		System.out.println("Số chẵn: " + num);
	}

	static void Ex6_Question1() {
		System.out.print("Số chẵn nguyên dương nhỏ hơn 10: ");
		for (int i = 2; i < 10; i += 2) {
			System.out.print(i);
			if (i != 8)
				System.out.print(", ");
		}
	}

	static void Ex6_Question3() {
		System.out.println("");
		System.out.print("Số nguyên dương nhỏ hơn 10: ");
		for (int i = 1; i < 10; i++) {
			System.out.print(i);
			if (i != 9)
				System.out.print(", ");
		}
	}

	static void Day3_Ex1_Question1() {
		float salaryAccount1 = 5240.5f;
		float salaryAccount2 = 10970.055f;

		int roundedSalaryAccount1 = (int) salaryAccount1;
		int roundedSalaryAccount2 = (int) salaryAccount2;

		System.out.println("Account 1: " + roundedSalaryAccount1 + "$");
		System.out.println("Account 2: " + roundedSalaryAccount2 + "$");
	}

	static Integer Day3_Ex1_Question2(Random random) {
		int number = random.nextInt(90000) + 10000;
		System.out.println("Số ngẫu nhiên có 5 chữ số: " + number);
		return number;
	}

	static void Day3_Ex1_Question3(Integer number) {
		String numberStr = String.valueOf(number);
		System.out.println("Hai số cuối: " + numberStr.substring(numberStr.length() - 2));
	}

	static Float Day3_Ex1_Question4(Scanner scanner) {
		System.out.println("Nhập vào số nguyên");

		int num1 = Utility.getValidInput(scanner, "Số thứ nhất: ", InputType.INT);
		int num2 = Utility.getValidInput(scanner, "Số thứ hai: ", InputType.NON_ZERO_INTEGER);

		float quotient = (float) num1 / num2;

		System.out.println("Các số đã nhập: " + num1 + ", " + num2);
		System.out.println("Thương số: " + quotient);
		return quotient;
	}

	static void Day3_Ex2_Question1() {
		Account[] accounts = new Account[5];

		for (int i = 0; i < accounts.length; i++) {
			accounts[i] = new Account("Email " + (i + 1), "Username " + (i + 1), "Fullname " + (i + 1));
		}

		System.out.println("Danh sách accounts: ");
		for (Account account : accounts) {
			System.out.println(account);
		}
	}

	static void Day3_Ex3_Question1() {
		Integer salary = 5000;
		Float floatSalary = salary.floatValue();
		System.out.printf("Lương: %.2f%n", floatSalary);
		System.out.println("Kiểu dữ liệu: " + floatSalary.getClass().getName());
	}

	static void Day3_Ex3_Question2() {
		String str = "1234567";
		Integer integerStr = Integer.parseInt(str);
		System.out.println("Convert to int: " + integerStr);
		System.out.println("Kiểu dữ liệu: " + integerStr.getClass().getName());
	}

	static void Day3_Ex3_Question3() {
		String strNumber = "1234567";
		int intNumber = Integer.parseInt(strNumber);
		System.out.println("Số: " + intNumber);
		System.out.println("Kiểu dữ liệu: " + ((Object) intNumber).getClass().getName());
	}

	static void Day3_Ex4_Question1(Scanner scanner) {
		System.out.println("Nhập xâu kí tự: ");
		String str = scanner.nextLine().trim();
		System.out.println("Chuỗi đã nhập: " + str);
		System.out.println("Độ dài chuỗi kí tự: " + str.length());
	}

	static void Day3_Ex4_Question2(Scanner scanner) {
		System.out.println("Nhập chuỗi kí tự");
		System.out.println("Chuỗi 1: ");
		String str1 = scanner.nextLine().trim();
		System.out.println("Chuỗi 2: ");
		String str2 = scanner.nextLine().trim();
		System.out.println("Chuỗi đã nhập: " + str1.concat(str2));
	}

	static void Day3_Ex4_Question3(Scanner scanner) {
		String name = Utility.getValidInput(scanner, "Nhập tên: ", InputType.NAME);
		System.out.println("Tên đã nhập: " + Utility.capitalizeWords(name));
	}

	static void Day3_Ex4_Question4(Scanner scanner) {
		String name = Utility.getValidInput(scanner, "Nhập tên: ", InputType.NAME);
		for (int i = 0; i < name.length(); i++) {
			System.out.println("Kí tự thứ " + (i + 1) + " là: " + name.substring(i, i + 1));
		}
	}

	static void Day3_Ex4_Question5(Scanner scanner) {
		String lastName = Utility.getValidInput(scanner, "Nhập họ: ", InputType.NAME);
		String firstName = Utility.getValidInput(scanner, "Nhập tên: ", InputType.NAME);

		System.out.println(
				"Họ và tên đầy đủ: " + Utility.capitalizeWords(lastName) + " " + Utility.capitalizeWords(firstName));
	}

	static void Day3_Ex4_Question6(Scanner scanner) {
		String name = Utility.getValidInput(scanner, "Nhập họ và tên: ", InputType.NAME_PARTS);
		FullName fullName = Utility.getNameParts(name);
		System.out.println("Họ là: " + fullName.getLastName());
		System.out.println("Tên đệm là: " + fullName.getMiddleName());
		System.out.println("Tên là: " + fullName.getFirstName());
	}

	static void Day3_Ex4_Question7(Scanner scanner) {
		String name = Utility.getValidInput(scanner, "Nhập họ và tên: ", InputType.FULLNAME);
		System.out.println("Tên đã nhập: " + Utility.capitalizeWords(name));
	}
}
