import java.time.LocalDateTime;

public class Account {
	String id;
	String email;
	String userName;
	String fullName;
	LocalDateTime createDate;
	
	public Account(String email, String userName, String fullName) {
		super();
		this.id = Utility.generateUniqueId();
		this.email = email;
		this.userName = userName;
		this.fullName = fullName;
		this.createDate = LocalDateTime.now();
	}

	@Override
	public String toString() {
		return "Account [id=" + id + ", email=" + email + ", userName=" + userName + ", fullName=" + fullName
				+ ", createDate=" + createDate + "]";
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
}
