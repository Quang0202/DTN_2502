
class InputResult<T> {
	T value;
	String errorMessage;
	
	public InputResult(T value, String errorMessage) {
		super();
		this.value = value;
		this.errorMessage = errorMessage;
	}

	public T getValue() {
		return value;
	}

	public void setValue(T value) {
		this.value = value;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public boolean isValid() {
		return errorMessage == null;
	}
	
}
