
import java.util.UUID;
import java.util.Arrays;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Utility {

	// Phương thức lấy dữ liệu hợp lệ
	static <T> T getValidInput(Scanner scanner, String message, InputType type) {
		while (true) {
			System.out.println(message);

			InputResult<T> result = (InputResult<T>) checkAndGetInput(scanner, type);

			if (result.isValid())
				return result.getValue();

			System.out.println(result.getErrorMessage());

			if (type != InputType.FULLNAME && type != InputType.NAME && type != InputType.NAME_PARTS)
				scanner.nextLine(); // Xoá dữ liệu không hợp lệ trong buffer
		}
	}

	// Phương thức xử lý và lấy dữ liệu đầu vào theo kiểu InputType
	static InputResult<Object> checkAndGetInput(Scanner scanner, InputType type) {
		Object value = null;
		String errorMessage = null;
		int MIN_LENGTH;

		switch (type) {
		case INT:
			if (scanner.hasNextInt())
				value = scanner.nextInt();
			else
				errorMessage = "Lỗi! Vui lòng nhập số nguyên hợp lệ!";
			break;

		case NON_ZERO_INTEGER:
			if (scanner.hasNextInt()) {
				int sc = scanner.nextInt();
				if (sc != 0)
					value = sc;
				else
					errorMessage = "Lỗi! Vui lòng nhập số nguyên khác 0!";
			} else
				errorMessage = "Lỗi! Vui lòng nhập số nguyên hợp lệ!";
			break;

		case FLOAT:
			if (scanner.hasNextFloat())
				value = scanner.nextFloat();
			else
				errorMessage = "Lỗi! Vui lòng nhập số thực hợp lệ!";
			break;

		case FULLNAME:
			MIN_LENGTH = 8;
			return getValidString(scanner, MIN_LENGTH);

		case NAME:
			MIN_LENGTH = 2;
			return getValidString(scanner, MIN_LENGTH);

		case NAME_PARTS:
			return getValidNameParts(scanner);

		case DATETIME:
			return parseDate(scanner);

		case EVEN:
			if (scanner.hasNextInt()) {
				int number = scanner.nextInt();
				if (number % 2 == 0) {
					value = number;
				} else
					errorMessage = "Lỗi: Vui lòng nhập một số chẵn.";
			} else
				errorMessage = "Lỗi: Vui lòng nhập một số nguyên.";
			break;
		default:
			errorMessage = "Lỗi: Kiểu dữ liệu không hợp lệ.";
		}

		return new InputResult<>(value, errorMessage);
	}

	// Kiểm tra đối với type NAME
	static InputResult<Object> getValidString(Scanner scanner, int minLength) {
		String input = scanner.nextLine().trim();
		String errorMessage = null;

		// Kiểm tra độ dài chuỗi nhập vào
		if (input.length() < minLength) {
			errorMessage = "Lỗi: Cần nhập ít nhất " + minLength + " ký tự.";
		}
		// Kiểm tra chỉ cho phép các kí tự chữ và có dấu
		if (!input.matches("[a-zA-Záàảãạăắằẳẵặâấầẩẫậđéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵ\\s]+")) {
			errorMessage = "Lỗi: Chỉ được chứa chữ cái, không được có số hay ký tự đặc biệt.";
		}

		return new InputResult<>(errorMessage == null ? input : null, errorMessage);
	}

	static InputResult<Object> getValidNameParts(Scanner scanner) {
		String input = scanner.nextLine().trim();
		String errorMessage = null;

		// Kiểm tra chỉ cho phép các kí tự chữ và có dấu
		if (!input.matches("[a-zA-Záàảãạăắằẳẵặâấầẩẫậđéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵ\\s]+")) {
			errorMessage = "Lỗi: Chỉ được chứa chữ cái, không được có số hay ký tự đặc biệt.";
		}

		String[] nameParts = input.split("\\s+");

		if (nameParts.length < 2) {
			errorMessage = "Lỗi: Chưa nhập đầy đủ họ và tên!";
		}

		return new InputResult<>(errorMessage == null ? input : null, errorMessage);
	}

	static FullName getNameParts(String name) {
		String[] nameParts = name.split("\\s+");

		String lastName = null;
		String middleName = null;
		String firstName = null;

		// Kiểm tra số phần tử trong nameParts
		switch (nameParts.length) {
		case 2:
			lastName = nameParts[0];
			firstName = nameParts[1];
			break;

		case 3:
			lastName = nameParts[0];
			middleName = nameParts[1];
			firstName = nameParts[2];
			break;

		default:
			if (nameParts.length > 3) {
				lastName = nameParts[0];
				middleName = String.join(" ", Arrays.copyOfRange(nameParts, 1, nameParts.length - 1));
				firstName = nameParts[nameParts.length - 1];
			}
			break;
		}

		return new FullName(lastName, middleName, firstName);
	}

	// Kiểm tra đối với type DateTime
	static InputResult<Object> parseDate(Scanner sc) {
		String dateTimeInput = sc.next();

		// Sửa lại định dạng nếu nhập /
		String formattedDate = dateTimeInput.replace("/", "-");

		// Kiểm tra 2 kiểu format date
		DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");

		LocalDate date = null;
		// Thử phân tích theo định dạng yyyy-MM-dd
		try {
			date = LocalDate.parse(formattedDate, formatter1);
		} catch (Exception e) {
			// Nếu không thành công, thử phân tích theo định dạng dd-MM-yyyy
			try {
				date = LocalDate.parse(formattedDate, formatter2);
			} catch (Exception ex) {
				// Nếu cả hai định dạng đều không hợp lệ
				return new InputResult<>(null, "Lỗi: Vui lòng nhập ngày theo định dạng yyyy-MM-dd hoặc dd-MM-yyyy");
			}
		}
		return new InputResult<>(date, null);
	}

	// Tạo Id duy nhất
	static String generateUniqueId() {
		return UUID.randomUUID().toString();
	};

	// Viết hoa chữ cái đầu
	static String capitalizeWords(String str) {
		String[] words = str.split("\\s");
		StringBuilder result = new StringBuilder();

		for (String word : words) {
			result.append(word.substring(0, 1).toUpperCase());
			result.append(word.substring(1).toLowerCase());
			result.append(" ");
		}

		return result.toString().trim();
	}

}
