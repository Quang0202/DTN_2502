import java.util.Date;
import java.util.Locale;
import java.util.Random;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ThreadLocalRandom;

public class Main {

	public static void main(String[] args) {
		Date createDate = new Date();
		Random random = new Random();

		Ex2_question1();
		Ex2_question2();
		Ex2_question3();
		Ex2_question4();
		Ex2_question5();
		Ex2_question6();

		Ex3_question1(createDate);
		Ex3_question2(createDate);
		Ex3_question3(createDate);
		Ex3_question4(createDate);
		Ex3_question5(createDate);

		Ex4_question1(random);
		Ex4_question2(random);
		Ex4_question3(random);
		Ex4_question4();
		Ex4_question5();
		Ex4_question6();
		Ex4_question7(random);
	}

	static void Ex2_question1() {
		// Khai báo 1 số nguyên = 5 và dùng lệnh printf để in ra
		int number = 5;
		System.out.printf("Số nguyên: %d%n", number);
	}

	static void Ex2_question2() {
		int number = 100_000_000;
		System.out.printf("Số nguyên có định dạng: %,d%n", number);
	}

	static void Ex2_question3() {
		double number = 5.567098;
		System.out.printf("Số thực: %.4f%n", number);
	}

	static void Ex2_question4() {
		String name = "Nguyễn Văn A";
		System.out.printf("Tên tôi là \"%s\" và tôi đang độc thân", name);
	}

	static void Ex2_question5() {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH'h':mm'p':ss's'");
		System.out.println(now.format(formatter));
	}

	static void Ex2_question6() {
		String[] accounts = { "ID		|	Username	|	Email", "1		|	user1		|	user1@gmail.com",
				"2		|	user2		|	user2@gmail.com", "3		|	user3		|	user3@gmail.com" };

		for (String acc : accounts) {
			System.out.println(acc);
		}
	}

	static void Ex3_question1(Date createDate) {
		SimpleDateFormat formatter = new SimpleDateFormat("EEEE, dd MMMM yyyy", new Locale("vi", "VN"));
		System.out.println("Ngày tạo: " + formatter.format(createDate));
	}

	static void Ex3_question2(Date createDate) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println("Ngày tạo: " + formatter.format(createDate));
	}

	static void Ex3_question3(Date createDate) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy");
		System.out.println("Năm: " + formatter.format(createDate));
	}

	static void Ex3_question4(Date createDate) {
		SimpleDateFormat formatter = new SimpleDateFormat("MM-yyyy");
		System.out.println("Tháng và năm: " + formatter.format(createDate));
	}

	static void Ex3_question5(Date createDate) {
		SimpleDateFormat formatter = new SimpleDateFormat("MM-dd");
		System.out.println("MM-DD: " + formatter.format(createDate));
	}

	static void Ex4_question1(Random random) {
		System.out.println("Số nguyên ngẫu nhiên: " + random.nextInt());
	}

	static void Ex4_question2(Random random) {
		System.out.println("Số thực ngẫu nhiên: " + random.nextDouble());
	}

	static void Ex4_question3(Random random) {
		String[] names = { "An", "Bình", "Châu", "Duy", "Hải" };
		System.out.println("Tên ngẫu nhiên:" + names[random.nextInt(names.length)]);
	}

	static void Ex4_question4() {
		LocalDate start = LocalDate.of(1995, 7, 24);
		LocalDate end = LocalDate.of(1995, 12, 20);
		long randomDays = ThreadLocalRandom.current().nextLong(ChronoUnit.DAYS.between(start, end) + 1);
		System.out.println("Ngày ngẫu nhiên: " + start.plusDays(randomDays));
	}

	static void Ex4_question5() {
		LocalDate now = LocalDate.now();
		LocalDate lastYear = now.minusYears(1);
		long randomDays = ThreadLocalRandom.current().nextLong(ChronoUnit.DAYS.between(lastYear, now) + 1);
		System.out.println("Ngày ngẫu nhiên trong 1 năm qua: " + lastYear.plusDays(randomDays));
	}

	static void Ex4_question6() {
		LocalDate now = LocalDate.now();
		LocalDate randomPast = now.minusDays(ThreadLocalRandom.current().nextLong(1, 10000));
		System.out.println("Ngày ngẫu nhiên trong quá khứ: " + randomPast);
	}

	static void Ex4_question7(Random random) {
		int number = 100 + random.nextInt(900);
		System.out.println("Số có 3 chữ số: " + number);
	}
}
